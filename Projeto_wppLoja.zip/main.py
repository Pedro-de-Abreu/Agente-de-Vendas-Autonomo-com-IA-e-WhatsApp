#Bloco 1 - Importações

import os
import uvicorn
from fastapi import FastAPI, HTTPException, Form, Response
from pydantic import BaseModel
import google.generativeai as genai
from dotenv import load_dotenv
import banco_de_dados
import estoque

#Bloco 2 - KEY Gemini

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=API_KEY)

#Bloco 3 - Regras da Pessoa IA (Vendedor)
catalogo_texto = estoque.formatar_catalogo()
regras_de_vendas = f"""
Você é a Maria Luiza ou se preferirem Malu
1. É uma vendadora de tênis.
2. Seja legal
3. Vendedora da loja King Shoes
4. importar os produtos do estoque.py e gerar o texto do que tem lá
5. Seu objetivo é guiar o cliente para a compra.
6. Responda APENAS com base nos produtos listados abaixo. Se não tivermos, peça desculpas.
7. REGRA DE FORMATAÇÃO (WHATSAPP):
   - JAMAIS use asteriscos "*" para fazer listas de tópicos. Use hifens (-) ou emojis (👟, 👉).
   - Para destacar/negrito, use um asterisco em vol ta da palavra. Exemplo: *Preço:* e não **Preço:**.
   - Pule linhas entre os produtos para não ficar embolado.

ESTOQUE ATUAL:
{catalogo_texto}
... (regras) ...
"""

model = genai.GenerativeModel(
    'models/gemini-2.5-flash',
    system_instruction=regras_de_vendas
)

#Bloco 4 - Chamada da API e Chats

app = FastAPI(title="Agente de Vendas King Shoes")

class UserMessage(BaseModel):
    user_id: str
    message: str

#Bloco 5 - Atendimento da IA - Passo a passo da construção da memoria do banco de dados no atendimento (ROTA DE TESTE)

@app.post("/chat")
async def chat_with_agent(user_msg: UserMessage):
    try:
        chat_id = user_msg.user_id
        historico = banco_de_dados.carregar_historico(chat_id)
        chat_session = model.start_chat(history=historico)
        banco_de_dados.salvar_mensagem(chat_id, "user", user_msg.message)
        response = chat_session.send_message(user_msg.message)
        banco_de_dados.salvar_mensagem(chat_id, "model", response.text)

        return {"response": response.text}
    except Exception as e:
        print(f"Erro: {e}") 
        raise HTTPException(status_code=500, detail="Erro interno no servidor de IA")

#Bloco 6 - Rota e Configuração Wpp

@app.post("/whatsapp")
async def reply_whatsapp(Body: str = Form(), From: str = Form()):
    """
    O Twilio manda os dados como formulário (Form Data).
    'Body' é a mensagem do cliente.
    'From' é o número do cliente (nosso user_id).
    """
    try:
        chat_id = From
        msg_cliente = Body
        print(f"--- MENSAGEM DO ZAP DE: {chat_id} ---")
        print(f"Dizendo: {msg_cliente}")
        historico = banco_de_dados.carregar_historico(chat_id)
        chat_session = model.start_chat(history=historico)
        banco_de_dados.salvar_mensagem(chat_id, "user", msg_cliente)
        response = chat_session.send_message(msg_cliente)
        texto_resposta = response.text
        texto_resposta = texto_resposta.replace("**", "*")
        banco_de_dados.salvar_mensagem(chat_id, "model", texto_resposta)
        xml_response = f"""<?xml version="1.0" encoding="UTF-8"?>
        <Response>
            <Message>{texto_resposta}</Message>
        </Response>"""
        
        return Response(content=xml_response, media_type="application/xml")

    except Exception as e:
        print(f"Erro no WhatsApp: {e}")
        return Response(content=str(e), status_code=500)

#Bloco 7 - Start para rodar o projeto

if __name__ == "__main__":
    banco_de_dados.criar_tabela()
    uvicorn.run(app, host="0.0.0.0", port=8000)