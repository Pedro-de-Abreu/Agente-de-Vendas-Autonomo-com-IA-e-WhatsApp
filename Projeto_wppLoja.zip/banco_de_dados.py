#SQL com as criações e definições de comandos

import sqlite3
from datetime import datetime

NOME_BANCO = "loja_database.db"

def conectar():
    """Conecta ao banco de dados SQLite"""
    return sqlite3.connect(NOME_BANCO)

def criar_tabela():
    """Cria a tabela de histórico se ela não existir"""
    conn = conectar()
    cursor = conn.cursor()
    
    # Criamos uma tabela simples caso nao exista uma
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS historico (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    conn.commit()
    conn.close()
    print("--- Tabela de banco de dados verificada/criada com sucesso ---")

def salvar_mensagem(user_id, role, content):
    """Salva uma mensagem no banco"""
    conn = conectar()
    cursor = conn.cursor()
    
    cursor.execute("""
    INSERT INTO historico (user_id, role, content)
    VALUES (?, ?, ?)
    """, (user_id, role, content))
    
    conn.commit()
    conn.close()

def carregar_historico(user_id):
    """Lê todas as mensagens antigas de um usuário"""
    conn = conectar()
    cursor = conn.cursor()
    
    # Pega as mensagens ordenadas por tempo (mais antigas primeiro)
    cursor.execute("""
    SELECT role, content 
    FROM historico 
    WHERE user_id = ? 
    ORDER BY id ASC
    """, (user_id,))
    
    mensagens = cursor.fetchall()
    conn.close()
    
    historico_formatado = []
    for role, content in mensagens:
        historico_formatado.append({
            "role": role,
            "parts": [content]
        })
        
    return historico_formatado

if __name__ == "__main__":
    criar_tabela()